
public class Supermercado2 implements Supermercado{

	private int Total;
	private int nLatas;
	private int cliente;
	public Supermercado2(int total) {
		this.Total = total;		//número máximo de latas
		this.nLatas = total; 	//número de latas disponibles
		cliente = -1; 			//id del cliente atendido por el cajero
	}
	
	/* 	Este método lo utiliza un Cliente para coger num latas del lineal.
		En el ejercicio 2, num >=1 && num <= N_LATAS.
	*/
	public  void comprarLatas(int id,int num){
		 //TODO
		 
		System.out.println("Cliente "+id+" quiere "+num+". Hay "+nLatas);
				
		System.out.println("Cliente "+id+" compra "+num+" en el supermercado. Queda: "+nLatas);		
	}

	/* 	Este método lo utiliza el Reponedor para esperar el aviso de un 
		Cliente por falta de latas.		
	*/
	public  void esperarPeticion() throws InterruptedException{
		//TODO
		
		System.out.println("El reponedor ha sido despertado");
		
	}

	/* 	Este método lo utiliza el Reponedor para reponer las latas
	    en el supermercado, asegurándose que haya N_LATAS.		
	*/
	public  void nuevoSuministro() {
		//TODO
		System.out.println("El reponedor pone nuevos suministros");			
	}

	/* 	Este método lo utiliza un Cliente para pagar en la caja.		
	*/
	public  void pagar(int id) throws InterruptedException {
		//TODO
		
		System.out.println("Cliente "+id+" empieza a pagar");
		
		System.out.println("Cliente "+id+" ha terminado de pagar y se va");
		
	}

	/* 	Este método lo utiliza el Cajero para cobrar a un Cliente.		
	*/
	public  void cobrar() throws InterruptedException {
		//TODO
		
		System.out.println("Cajero cobra al cliente "+cliente);
		
		System.out.println("Cajero está disponible para otro cliente");
		
	}
}

