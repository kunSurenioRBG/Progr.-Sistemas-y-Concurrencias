
public class Supermercado1 implements Supermercado{

	private int Total;	
	private int nLatas;
	private int cliente;
	
	public Supermercado1(int total) {
		this.Total = total;		//número máximo de latas
		this.nLatas = total; 	//número de latas disponibles
		cliente = -1; 			//id del cliente atendido por el cajero
	}
	
	/* 	Este método lo utiliza un Cliente para coger num latas del lineal.
		En el ejercicio 1, num siempre es 1.
	*/
	public  void comprarLatas(int id,int num) throws InterruptedException{
		//TODO
		
		System.out.println("Cliente "+id+" compra en el supermercado "+num+" latas. Quedan: "+nLatas);
		
		System.out.println("Cliente "+id+" avisa al reponedor");		
	}

	/* 	Este método lo utiliza el Reponedor para esperar el aviso de un 
		Cliente por falta de latas.		
	*/
	public  void esperarPeticion() throws InterruptedException{
		//TODO
		
		System.out.println("El reponedor ha sido despertado");
		
	}

	/* 	Este método lo utiliza el Reponedor para reponer las latas, 
	    asegurándose que hay N_LATAS en el supermercado.		
	*/
	public  void nuevoSuministro() {
		//TODO
		
		System.out.println("El reponedor pone nuevos suministros");
		
	}

	/* 	Este método lo utiliza un Cliente para pagar en la caja.		
	*/
	public  void pagar(int id) throws InterruptedException {
		//TODO
		
		System.out.println("Cliente "+id+" empieza a pagar");
		
		System.out.println("Cliente "+id+" ha terminado de pagar y se va");
		
	}

	/* 	Este método lo utiliza el Cajero para cobrar a un Cliente.		
	*/
	public  void cobrar() throws InterruptedException {
		//TODO
		
		System.out.println("Cajero cobra al cliente "+cliente);
		
		System.out.println("Cajero está disponible para otro cliente");

	}
}
