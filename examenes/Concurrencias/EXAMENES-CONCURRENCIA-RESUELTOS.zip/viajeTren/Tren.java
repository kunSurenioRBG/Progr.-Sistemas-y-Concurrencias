package viajeTren;

import java.util.concurrent.Semaphore;

public class Tren {
	private Semaphore mutex = new Semaphore(1);
	private Semaphore puedoSubir = new Semaphore(1);
	private Semaphore puedoBajarVagon1 = new Semaphore(0);
	private Semaphore puedoBajarVagon2 = new Semaphore(0);
	private Semaphore inicioViaje = new Semaphore(0);

	private int pasajeros = 0;
	public void viaje(int id) throws InterruptedException {
		puedoSubir.acquire();
		mutex.acquire();
		++pasajeros;
		if(pasajeros <11){
			System.out.println("EL PASAJERO "+ id + " SE VA A SUBIR AL PRIMER VAGON");
			puedoSubir.release();
			mutex.release();

			puedoBajarVagon1.acquire();
			mutex.acquire();
			pasajeros--;
			System.out.println("EL PASAJERO "+ id +" SE HA BAJADO DEL VAGON 1, QUEDAN "+ pasajeros + " PASAJEROS");
			if(pasajeros > 10) {
				puedoBajarVagon1.release();
				mutex.release();
			}
			else{
				puedoBajarVagon2.release();
				mutex.release();
			} 
		}else{
			System.out.println("EL PASAJERO "+ id + " SE VA A SUBIR AL SEGUNDO VAGON");
			if(pasajeros < 20)puedoSubir.release();
			else inicioViaje.release();
			mutex.release();

			puedoBajarVagon2.acquire();
			mutex.acquire();
			pasajeros--;
			System.out.println("EL PASAJERO "+ id + " SE HA BAJADO DEL VAGON 2, QUEDAN "+ pasajeros+" PASAJEROS");
			if(pasajeros > 0)puedoBajarVagon2.release();
			else puedoSubir.release();
			mutex.release();
		
		}
			
	}

	public void empiezaViaje() throws InterruptedException {
		inicioViaje.acquire();
		System.out.println("        Maquinista:  empieza el viaje");
	
		
	}
	public void finViaje() throws InterruptedException  {
		
		System.out.println("        Maquinista:  fin del viaje");
		puedoBajarVagon1.release();
	}
}
