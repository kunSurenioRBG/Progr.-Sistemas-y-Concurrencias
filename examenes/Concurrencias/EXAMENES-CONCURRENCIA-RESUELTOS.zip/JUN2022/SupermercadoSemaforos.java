package JUN2022;

import java.util.concurrent.Semaphore;

import javax.sound.sampled.SourceDataLine;

public class SupermercadoSemaforos implements Supermercado {

	
	
	private Cajero permanente;

	//Nclientes > 3* Ncajeros -> creo un cajero temporal	
	
	private Semaphore mutex = new Semaphore(1);
	private Semaphore puedoEntrar = new Semaphore(1);
	private Semaphore atiendo = new Semaphore(0);
	private Semaphore atiendoOcasional = new Semaphore(0);
	private Semaphore cierroSuper = new Semaphore(0);
	private int clientes = 0;
	private int cajeros = 1;
	boolean abierto = true;
	public SupermercadoSemaforos() throws InterruptedException {
		permanente = new Cajero(this, true); //crea el primer cajero, el permanente
		permanente.start();		
		//TODO
	}

	@Override
	public void fin() throws InterruptedException {
		System.out.println("SUPERMERCADO CERRADO!!!");
		abierto = false;
		cierroSuper.acquire();
		System.out.println("CAJERO PERMANENTE TERMINA");
		}

	@Override
	public void nuevoCliente(int id) throws InterruptedException {
		if(abierto){
			puedoEntrar.acquire();
			mutex.acquire();
			clientes++;
			System.out.println("Llega el cliente "+ id + " HAY "+ clientes +" CLIENTES");
			if(clientes == 1)  atiendo.release();
			else if(clientes > 3*cajeros){
				System.out.println("SE CREA UN NUEVO CAJERO "+ cajeros);
				++cajeros;
				Cajero ocasional = new Cajero(this, false);
				ocasional.start();
				atiendoOcasional.release();
			}
			mutex.release();
			puedoEntrar.release();
		}

	}

	@Override
	public boolean permanenteAtiendeCliente( int id) throws InterruptedException {
		atiendo.acquire();
		mutex.acquire();

		if(clientes > 0){
			clientes--;
			System.out.println("CAJERO PERMANENTE ATIENDA A UN CLIENTE QUEDAN "+ clientes);
			mutex.release();
			atiendo.release();
			return true;
		}
		else{
			if(abierto){
				System.out.println("CAJERO PERMANENTE ESPERA");
			}else cierroSuper.release();
			mutex.release();
			atiendo.release();
			return false;
		} 
		
	}
		
	
	@Override
	public boolean ocasionalAtiendeCliente(int id) throws InterruptedException {
		atiendoOcasional.acquire();		
		mutex.acquire();
		if(clientes > 0){
			clientes--;
			System.out.println("CAJERO "+ id + " ATIENDE A CLIENTE QUEDAN "+ clientes);
			mutex.release();
			if(abierto)atiendoOcasional.release();
			return true;
		}else{
			System.out.println("NO HAY CLIENTES CAJERO "+ id +" TERMINA");
			cajeros--;
			mutex.release();
			if(!abierto) cierroSuper.release();
			return false;
		}
		//return true;//borrar
	}

}
