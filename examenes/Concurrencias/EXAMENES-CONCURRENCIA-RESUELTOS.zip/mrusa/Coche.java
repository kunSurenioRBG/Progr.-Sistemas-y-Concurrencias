package mrusa;

import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.*;

public class Coche implements Runnable {
	private int tam;
	private Semaphore mutex = new Semaphore(1, true);
	private Semaphore coche = new Semaphore(0, true);
	private Semaphore puedoSubir = new Semaphore(1, true);
	private Semaphore puedoBajar = new Semaphore(0, true);
	public Coche(int tam) {
		this.tam = tam;
	}
	private int asientosUsados= 0;

	public void subir(int id) throws InterruptedException {
		// id del pasajero que se sube al coche
		puedoSubir.acquire();
		mutex.acquire();
		asientosUsados++;
		System.out.println("El pasajero "+ id + " se ha subido al coche quedan " + (tam - asientosUsados)+ " asientos");
		mutex.release();
		if(asientosUsados == tam) coche.release();
		else puedoSubir.release();
	}

	public void bajar(int id) throws InterruptedException {
		puedoBajar.acquire();
		mutex.acquire();
		asientosUsados--;
		System.out.println("El pasajero " + id + " se baja del coche, quedan "+ (asientosUsados) + " personas por irse");
		mutex.release();
		if(asientosUsados == 0){
			System.out.println("	SE PUEDEN SUBIR NUEVOS PASAJEROS");
			puedoSubir.release();
		
		}
		else puedoBajar.release();
	}

	private void esperaLleno() throws InterruptedException {
		coche.acquire();
		System.out.println("	EL COCHE YA ESTA LLENO VAMOS A ARRANCAR");

		System.out.println("	EL VIAJE HA TERMINADO");
		puedoBajar.release();
		mutex.release();
	}

	public void run() {
		while (true)
			try {
				this.esperaLleno();
				Thread.sleep(200);

			} catch (InterruptedException ie) {
			}

	}
}
// tam pasajeros se suben al coche->el coche da un viaje
// ->tam pasajeros se bajan del coche->......

// CS-Coche: Coche no se pone en marcha hasta que no está lleno
// CS-Pas1: Pasajero no se sube al coche hasta que no hay sitio para el.
// CS-Pas2: Pasajero no se baja del coche hasta que no ha terminado el viaje
