package SEP2020;

import java.net.SocketTimeoutException;
import java.util.concurrent.Semaphore;

public class Curso {
	//HECHO CON EXITO
	//Numero maximo de alumnos cursando simultaneamente la parte de iniciacion
	private final int MAX_ALUMNOS_INI = 10;
	private int inicialAlumnos = 0;
	private int AvanzadoALumno = 0;
	private int finALumnos = 0;
	private Semaphore mutex = new Semaphore(1);
	private Semaphore inicioCurso = new Semaphore(1);
	private Semaphore inicioAvanazado = new Semaphore(1);
	private Semaphore esperoAvanzado = new Semaphore(0);
	private Semaphore acaboCurso = new Semaphore(1);
	//Numero de alumnos por grupo en la parte avanzada

	//El alumno tendra que esperar si ya hay 10 alumnos cursando la parte de iniciacion
	public void esperaPlazaIniciacion(int id) throws InterruptedException{
		inicioCurso.acquire();
		mutex.acquire();
		System.out.println("EL ALUMNO "+ id + " VA A INICIAR EL CURSO DE INICIACIÓN");
		inicialAlumnos++;
		mutex.release();
		if(inicialAlumnos < MAX_ALUMNOS_INI) inicioCurso.release();

	}

	//El alumno informa que ya ha terminado de cursar la parte de iniciacion
	public void finIniciacion(int id) throws InterruptedException{
		mutex.acquire();
		System.out.println("EL ALUMNO "+ id + " HA ACABADO EL CURSO DE INICIACION");
		inicialAlumnos--;
		if(inicialAlumnos == MAX_ALUMNOS_INI -1) inicioCurso.release();
		mutex.release();
	}
	
	/* El alumno tendra que esperar:
	 *   - si ya hay un grupo realizando la parte avanzada
	 *   - si todavia no estan los tres miembros del grupo conectados
	 */
	public void esperaPlazaAvanzado(int id) throws InterruptedException{
		inicioAvanazado.acquire();
		mutex.acquire();
		System.out.println("PARTE AVANZADA: EL ALUMNO "+id+ " TIENE QUE ESPERAR A 3 ALUMNOS");
		++AvanzadoALumno;
		if(AvanzadoALumno < 3){
		inicioAvanazado.release();
		mutex.release();
		esperoAvanzado.acquire();
		
		mutex.acquire();
		AvanzadoALumno--;
		System.out.println("PARTE AVANZADA YA HAY 3 ALUMNOS. EL ALUMNO "+id + " VA A TRABAJAR" );
		if(AvanzadoALumno > 0)esperoAvanzado.release();
		mutex.release();
		}else{
			AvanzadoALumno--;
			System.out.println("PARTE AVANZADA YA HAY 3 ALUMNOS. EL ALUMNO "+id + " VA A TRABAJAR" );
			mutex.release();
			esperoAvanzado.release();

		}
		
	}	
	
	/* El alumno:
	 *   - informa que ya ha terminado de cursar la parte avanzada 
	 *   - espera hasta que los tres miembros del grupo hayan terminado su parte 
	 */ 
	public void finAvanzado(int id) throws InterruptedException{
		acaboCurso.acquire();
		mutex.acquire();
		finALumnos++;
		System.out.println("PARTE AVANZADA EL ALUMNO "+ id + " HA TERMINADO SU PARTE TIENE QUE ESPERAR AL RESTO");
		if(finALumnos < 3){
			acaboCurso.release();
			mutex.release();
			esperoAvanzado.acquire();
			mutex.acquire();
			--finALumnos;
			if(finALumnos == 0) {
				System.out.println("		LOS 3 ALUMNOS HAN ACABADO EL CURSO");
				acaboCurso.release();
				inicioAvanazado.release();
			}
			else esperoAvanzado.release();
			mutex.release();
		}else{
			finALumnos--;
			esperoAvanzado.release();
			mutex.release();
		}
	}
}
