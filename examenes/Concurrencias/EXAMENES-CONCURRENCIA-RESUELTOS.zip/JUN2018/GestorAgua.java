package JUN2018;


import java.util.concurrent.*;

public class GestorAgua {
	//EXAMEN HECHO CORRECTAMENTE :)
	private Semaphore hidrogeno = new Semaphore(1);
	private Semaphore oxigeno = new Semaphore(1);
	private Semaphore formarH20 = new Semaphore(0);
	private Semaphore mutex = new Semaphore(1);
	private int atomosHidrogeno = 0;
	private boolean atomoOxigeno = false;


	public void hListo(int id) throws InterruptedException{ 
		hidrogeno.acquire();
		System.out.println("El hidrogeno "+ id + " desea formar agua");
		mutex.acquire();
		atomosHidrogeno++;
		if(atomosHidrogeno < 2 && atomoOxigeno){
			hidrogeno.release();
			mutex.release();
			formarH20.acquire();
		}else{
			formarH20.release();
		}

		System.out.println("EL HIDROGENO "+ id + " HA FORMADO AGUA!!");
		
		atomosHidrogeno--;
		if(atomosHidrogeno == 0){
			
			hidrogeno.release();
			mutex.release();
		}else formarH20.release();
		
	}
	
	public void oListo(int id) throws InterruptedException{ 
		oxigeno.acquire();
		System.out.println("El oxigeno "+ id + " desea formar agua");
		atomoOxigeno = true;
		if(atomosHidrogeno < 2){
			formarH20.acquire();
		}else{
			formarH20.release();
		}
		System.out.println("EL OXIGENO "+ id + " HA FORMADO AGUA");
		atomoOxigeno = false;
		oxigeno.release();
	}
}