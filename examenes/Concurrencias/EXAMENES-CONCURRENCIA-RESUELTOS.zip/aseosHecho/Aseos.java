package aseosHecho;

import java.util.concurrent.Semaphore;

import javax.lang.model.util.ElementScanner6;
import javax.print.attribute.standard.NumberOfInterveningJobs;
import javax.print.attribute.standard.NumberUpSupported;

public class Aseos {

	/**
	 * Utilizado por el cliente id cuando quiere entrar en los aseos
	 * CS Version injusta: El cliente espera si el equipo de limpieza está
	 * trabajando
	 * CS Version justa: El cliente espera si el equipo de limpieza está trabajando
	 * o
	 * está esperando para poder limpiar los aseos
	 * 
	 * @throws InterruptedException
	 * 
	 */
	
	 private Semaphore mutex = new Semaphore(1, true);
	 private Semaphore entraLimpieza = new Semaphore(0, true);
	 private Semaphore entranClientes = new Semaphore(1, true);
	 private boolean quieroLimpiar = false;
	 private int numeroClientes = 0;
	public void entroAseo(int id) throws InterruptedException {
		
		entranClientes.acquire();
		mutex.acquire();
		++numeroClientes;
		System.out.println("El cliente " + id + " ha entrado en el baño."
			+ "Clientes en el aseo: " + numeroClientes);
		mutex.release();
		if(!quieroLimpiar) entranClientes.release();
	}

	/**
	 * Utilizado por el cliente id cuando sale de los aseos
	 * 
	 * @throws InterruptedException
	 * 
	 */
	public void salgoAseo(int id) throws InterruptedException {
		mutex.acquire();
		numeroClientes--;
		System.out.println("El cliente " + id + " ha salido del baño."
				+ "Clientes en el aseo: "+ numeroClientes);

		if(quieroLimpiar && numeroClientes == 0) entraLimpieza.release();		
		else mutex.release();
			
	}

	/**
	 * Utilizado por el Equipo de Limpieza cuando quiere entrar en los aseos
	 * CS: El equipo de trabajo está solo en los aseos, es decir, espera hasta que
	 * no
	 * haya ningún cliente.
	 * 
	 * @throws InterruptedException
	 * 
	 */
	public void entraEquipoLimpieza() throws InterruptedException {
		quieroLimpiar = true;
		entranClientes.acquire();
		System.out.println("	El equipo de limpieza desea entrar a limpiar");
		entraLimpieza.acquire();
		
		System.out.println("	El equipo de limpieza está trabajando.");
	}	

	/**
	 * Utilizado por el Equipo de Limpieza cuando sale de los aseos
	 * 
	 * @throws InterruptedException
	 * 
	 * 
	 */
	public void saleEquipoLimpieza() throws InterruptedException {
		
		quieroLimpiar = false;
		System.out.println("	El equipo de limpieza ha terminado.");
		entranClientes.release();
		mutex.release();
	}
}
