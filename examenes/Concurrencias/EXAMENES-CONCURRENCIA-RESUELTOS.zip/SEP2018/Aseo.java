package SEP2018;

import java.util.concurrent.Semaphore;

public class Aseo {
	//EXAMEN HECHO CON EXITO :)
	private Semaphore mutex = new Semaphore(1);
	private Semaphore entraHombre = new Semaphore(0);
	private Semaphore entraMujer = new Semaphore(1);

	private Semaphore salir = new Semaphore(0);
	private int hombres = 0;
	private int mujeres = 0;
	private boolean esperando = false;
	/**
	 * El hombre id quiere entrar en el aseo. 
	 * Espera si no es posible, es decir, si hay alguna mujer en ese
	 * momento en el aseo
	 */
	public void llegaHombre(int id) throws InterruptedException{
		entraHombre.acquire();
		mutex.acquire();
		hombres++;
		System.out.println("EL HOMBRE "+ id + " VA A USAR EL BAÑO HAY "+ hombres + " HOMBRES");
		mutex.release();
		entraHombre.release();
		salir.release();
	}
	/**
	 * La mujer id quiere entrar en el aseo. 
	 * Espera si no es posible, es decir, si hay algun hombre en ese
	 * momento en el aseo
	 */
	public void llegaMujer(int id) throws InterruptedException{
		entraMujer.acquire();
		mutex.acquire();
		mujeres++;
		System.out.println("LA MUJER "+id + " VA A USAR EL BAÑO HAY "+ mujeres + " MUJERES");
		mutex.release();
		entraMujer.release();
		salir.release();
	}
	/**
	 * El hombre id, que estaba en el aseo, sale
	 */
	public void saleHombre(int id)throws InterruptedException{
		salir.acquire();
		mutex.acquire();
		hombres--;
		System.out.println("EL HOMBRE "+ id +" SE VA DEL BAÑO QUEDAN "+ hombres + " HOMBRES");
		if(hombres == 0) {
			entraHombre.acquire();
			entraMujer.release();;
		}
		mutex.release();
	}
	
	public void saleMujer(int id)throws InterruptedException{
		salir.acquire();
		mutex.acquire();
		mujeres--;
		System.out.println("LA MUJER "+id+" SE VA DEL BAÑO QUEDAN "+ mujeres + " MUJERES");
		if(mujeres == 0){
			entraMujer.acquire();
			entraHombre.release();
		}
		mutex.release();
	}
}
