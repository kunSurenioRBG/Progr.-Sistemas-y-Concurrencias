package DIC2017;

import java.lang.annotation.Retention;
import java.util.concurrent.*;
public class Mesa {
    //0 - piedra, 1 - papel, 2 - tijeras
	
	/**
	 * 
	 * @param jug jugador que llama al m�todo (0,1,2)
	 * @param juego jugada del jugador (0-piedra,1-papel, 2-tijeras)
	 * @return  si ha habido un ganador en esta jugada se devuelve 
	 *          la jugada ganadora
	 *         o -1, si no ha habido ganador
	 * @throws InterruptedException
	 * 
	 * El jugador que llama a este m�todo muestra su jugada, y espera a que 
	 * est�n la de los otros dos. 
	 * Hay dos condiciones de sincronizaci�n
	 * CS1- Un jugador espera en el m�todo hasta que est�n las tres jugadas
	 * CS2- Un jugador tiene que esperar a que finalice la jugada anterior para
	 *     empezar la siguiente
	 * 
	 */
	private Semaphore mutex = new Semaphore(1);
	private Semaphore puedoLanzar = new Semaphore(1);
	private Semaphore esperoResultados = new Semaphore(0);
	private int jugadaJ1;
	private int jugadaJ2;
	private int jugadaJ3;
	private int tiradas = 0;
	public int nuevaJugada(int jug,int juego) throws InterruptedException{
		puedoLanzar.acquire();
		System.out.println("El jugador "+ jug + " ha tirado " + juego);
		if(jug == 0) jugadaJ1 = juego;
		else if(jug == 1) jugadaJ2 = juego;
		else jugadaJ3 = juego;
		tiradas++;
		
		if(tiradas == 3) esperoResultados.release();
		puedoLanzar.release();
		
		esperoResultados.acquire();
		int output = juego;
		if(jugadaJ1 == jugadaJ2 && jugadaJ1 == jugadaJ3) output =-1;
		else if(jugadaJ1 != jugadaJ2 && jugadaJ1 != jugadaJ3 && jugadaJ2 != jugadaJ3) output = -1;
		else
	
		return juego;
		return output;	
	}
}
