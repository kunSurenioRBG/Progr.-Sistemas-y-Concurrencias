package JUN2019;

import java.sql.PseudoColumnUsage;
import java.util.concurrent.Semaphore;

public class Tiovivo {
	private Semaphore mutex = new Semaphore(1,true);
	private Semaphore puedoSubir = new Semaphore(1,true);
	private Semaphore puedoBajar = new Semaphore(0,true);
	private Semaphore inicioViaje = new Semaphore(0,true);
	private Semaphore finViaje = new Semaphore(0,true);	
	private int t;

	public Tiovivo(int t){
		this.t= t;
	}

	private int pasajeros = 0;
	public void subir(int id) throws InterruptedException 
	{	
		puedoSubir.acquire();
		mutex.release();
		System.out.println("El pasajero "+ id +" se sube al tiovivo");
		pasajeros++;
		mutex.release();
		if(pasajeros < t) puedoSubir.release();
		else inicioViaje.release();
	}
	
	public void bajar(int id) throws InterruptedException 
	{
		puedoBajar.acquire();
		mutex.acquire();
		pasajeros--;
		System.out.println("El pasajero "+ id + " se baja del tiovivo. QUEDAN "+ pasajeros + " PASAJEROS");
		mutex.release();
		if(pasajeros > 0) puedoBajar.release();
		else{
			System.out.println("		EL TIOVIVO ESTA VACIO PUEDEN ENTRAR NUEVOS PASAJEROS");
			System.out.println("*****************************************************************************++");
			puedoSubir.release();
		}
	}
	
	public void esperaLleno () throws InterruptedException 
	{
		inicioViaje.acquire();
		System.out.println("El tiovivo esta lleno VAMOS A EMPEZAR");
		finViaje.release();
	}
	
	public void finViaje () throws InterruptedException 
	{
		finViaje.acquire();
		System.out.println("El viaje ha acabado pueden bajarse los pasajeros ya");
		puedoBajar.release();
	}
}
