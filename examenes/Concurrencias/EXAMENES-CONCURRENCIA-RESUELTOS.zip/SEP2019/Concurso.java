package SEP2019;

import java.util.concurrent.Semaphore;

public class Concurso {

	//EXAMEN HECHO CORRECTAMENTE :)
	private Semaphore mutex = new Semaphore(1);
	private Semaphore tiroMoneda = new Semaphore(1);
	private Semaphore acaboPartida = new Semaphore(0);
	private Semaphore espero = new Semaphore(0);
	private int tiradasJ1 = 0;
	private int victoriasJ1 = 0;
	private int tiradasJ2 = 0;
	private int victoriasJ2 = 0;
	private int juegosGanadosJ1 =0;
	private int juegosGanadosJ2 = 0;
	private int i = 1;

	private boolean anunciado = false;
	public void tirarMoneda(int id,boolean cara) throws InterruptedException{
		tiroMoneda.acquire();
		mutex.acquire();
		if(cara){
			if(id == 0)victoriasJ1++;
			else victoriasJ2++;
		}
		if(id == 0)tiradasJ1++;
		else tiradasJ2++;

		if(tiradasJ1 + tiradasJ2 == 20){
			if(tiradasJ1 > tiradasJ2){
				System.out.println("Juego "+ i + ": Ha ganado la partida el jugador 0 con " + victoriasJ1 +" caras");
				juegosGanadosJ1++;
			}else if(tiradasJ1 < tiradasJ2){
				System.out.println("Juego "+ i+ ": Ha ganado la partida el jugador 1 con " + victoriasJ2 + " caras"); 
				juegosGanadosJ2++;
			}else System.out.println("Juego "+ i + ": el juego ha empatado");

			tiradasJ1 = 0;
			tiradasJ2 = 0;
			victoriasJ1 = 0;
			victoriasJ2 = 0;
			i++;
			}
		mutex.release();
		tiroMoneda.release();
	}	
	
	public boolean concursoTerminado() throws InterruptedException {
		if(!anunciado){
			if(juegosGanadosJ1 == 3){
				System.out.println("Final del concurso. Ha ganado el jugador 0");
				anunciado = true;
				return true;
			}else if(juegosGanadosJ2 == 3 )  {
				System.out.println("Final del concurso. Ha ganado el jugador 1");
				anunciado = true;
				return true;
			}
		}else return anunciado;
		return anunciado;
	}
}
